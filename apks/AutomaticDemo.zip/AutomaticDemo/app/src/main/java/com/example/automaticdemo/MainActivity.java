package com.example.automaticdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LayoutAnimationController;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.automaticdemo.app.App;
import com.example.automaticdemo.databinding.ActivityMainBinding;
import com.example.automaticdemo.releaseui.CheckDeadFriActivity;
import com.example.automaticdemo.releaseui.GroupAddActivity;
import com.example.automaticdemo.releaseui.GroupSendActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        initView();
    }

    private void initView() {
        myAdapter = new MyAdapter();
        ((ListView) binding.getRoot().findViewById(R.id.listView)).setAdapter(myAdapter);
        //设置动画
        ((ListView) binding.getRoot().findViewById(R.id.listView)).setLayoutAnimation(getListAnim());
        //增加底线
        ((ListView) binding.getRoot().findViewById(R.id.listView)).addFooterView(View.inflate(this.getApplicationContext(), R.layout.baseline, null));
    }

    public class MyAdapter extends BaseAdapter {

        private List<FunctionBean> functionBeans = new ArrayList<FunctionBean>() {{
            add(new FunctionBean(R.drawable.ic_launcher_background, CheckDeadFriActivity.currentFunction, "微信检测死粉 - 启动辅助 - 打开微信 - 软件自动执行- 检测死粉完毕"));
            add(new FunctionBean(R.drawable.ic_launcher_background, GroupAddActivity.currentFunction, "微信群内加人 - 启动辅助 - 打开微信群 - 右上角三点 - 软件自动执行 - 添加群内用户完毕"));
            add(new FunctionBean(R.drawable.ic_launcher_background, GroupSendActivity.currentFunction, "微信图文群发 - 启动辅助 - 打开微信群 - 右上角三点 - 软件自动执行 - 微信图文群发"));
//            add(new FunctionBean(R.drawable.ic_launcher, NearbyAddActivity.currentFunction, "微信附近加人 - 启动辅助 - 打开微信 - 打开附近的人界面  - 软件自动执行- 附近自动加粉完毕"));
//            add(new FunctionBean(R.drawable.ic_launcher, GroupSendActivity.currentFunction, "微信群发助手 - 启动辅助 - 打开微信 - 打开群发助手界面 - 软件自动执行 - 群发选择联系人完毕"));
//            add(new FunctionBean(R.drawable.ic_launcher_background, SilenceCheckDeadFri.currentFunction, "微信静默检测死粉 - 启动辅助 - 打开微信 - 软件自动执行- 检测死粉完毕"));
        }};

        @Override
        public int getCount() {
            return functionBeans.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null)
                convertView = View.inflate(parent.getContext(), R.layout.item_main_lv, null);
            final FunctionBean functionBean = functionBeans.get(position);
            ((ImageView) convertView.findViewById(R.id.iv)).setBackgroundResource(functionBean.getImgResourcesId());
            ((TextView) convertView.findViewById(R.id.tvTitle)).setText(functionBean.getTitle());
            ((TextView) convertView.findViewById(R.id.tvDescribe)).setText(functionBean.getDescribe());
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switch (functionBean.getTitle()) {
                        //检测死粉(发消息检测死粉)
                        case CheckDeadFriActivity.currentFunction:
                            startActivity(new Intent(App.getContext(), CheckDeadFriActivity.class));
                            break;
                            //群内加人
                        case GroupAddActivity.currentFunction:
                            startActivity(new Intent(App.getContext(), GroupAddActivity.class));
                            break;
                            //图文群发
                        case GroupSendActivity.currentFunction:
                            startActivity(new Intent(App.getContext(), GroupSendActivity.class));
                            break;
//                        case GroupSendActivity.currentFunction:
//                            startActivity(new Intent(App.getContext(), GroupSendActivity.class));
//                            break;
//                        case NearbyAddActivity.currentFunction:
//                            startActivity(new Intent(App.getContext(), NearbyAddActivity.class));
//                            break;
//                        case SilenceCheckDeadFri.currentFunction:
//                            startActivity(new Intent(App.getContext(), SilenceCheckDeadFri.class));
//                            break;
                    }
                }
            });
            return convertView;
        }
    }

    private LayoutAnimationController getListAnim() {
        AnimationSet set = new AnimationSet(true);
        Animation animation = new AlphaAnimation(0.0f, 1.0f);
        animation.setDuration(500);
        set.addAnimation(animation);

        animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 1.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f,
                Animation.RELATIVE_TO_SELF, 0.0f);
        animation.setDuration(500);//设置动画时间
        set.addAnimation(animation);
        LayoutAnimationController controller = new LayoutAnimationController(
                set, 0.5f);
        return controller;
    }

    class FunctionBean {

        private int imgResourcesId;
        private String title;
        private String describe;

        public FunctionBean(int imgResourcesId, String title, String describe) {
            this.imgResourcesId = imgResourcesId;
            this.title = title;
            this.describe = describe;
        }

        public int getImgResourcesId() {
            return imgResourcesId;
        }

        public void setImgResourcesId(int imgResourcesId) {
            this.imgResourcesId = imgResourcesId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDescribe() {
            return describe;
        }

        public void setDescribe(String describe) {
            this.describe = describe;
        }
    }


}
