package com.example.automaticdemo.app;

import android.app.Application;
import android.content.Context;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;


public class App extends Application {

    //money 自动测试
    //cd C:\Users\27496\AppData\Local\Android\Sdk\platform-tools
    //adb shell monkey -p cn.hjc.automation 90000

    //签名命令
    //jarsigner -verbose -keystore automation.jks -signedjar automation_out.apk automation.apk public

    private static Context context;

    public static Context getContext() {
        return context;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
    }
}
