package com.example.automaticdemo.releaseui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.example.automaticdemo.R;
import com.example.automaticdemo.Service.AccessibilityUtils;
import com.example.automaticdemo.Service.AutomationAccessibilityService;
import com.example.automaticdemo.app.App;
import com.example.automaticdemo.base.BaseActivity;
import com.example.automaticdemo.databinding.ActivityCheckDeadFriBinding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheckDeadFriActivity extends BaseActivity {

    public static final String currentFunction = "检测死粉";
    private ActivityCheckDeadFriBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_check_dead_fri);
        setTitle(currentFunction);
        initView();
    }

    public void initView() {
        binding.switchFloating.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getOverlayPermission();
            }
        });

        binding.switchAccessibilityServices.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                openAccessibilityServiceSettings(CheckDeadFriActivity.this);
            }
        });
    }

    public void btnOnClick(View view) {
        //服务逻辑已经写好
        if (!(binding.switchFloating.isChecked() && binding.switchAccessibilityServices.isChecked())) {
            Toast.makeText(App.getContext(), "权限设置没有打开,请打开", Toast.LENGTH_SHORT).show();
            return;
        }
        int checkBeginNum = 0;
        try {
            checkBeginNum = Integer.parseInt(binding.etCheckBeginNum.getText().toString().trim());
        } catch (Exception e) {
            Toast.makeText(App.getContext(), "请正确输入从第 n 个好友开始检测", Toast.LENGTH_SHORT).show();
            return;
        }

        //初始化参数
        //发送信息
        CheckDeadFriActivity.Accessibility.sendMsg = "软件正在自动好友检测,勿回复;";
        //备注信息
        CheckDeadFriActivity.Accessibility.remarkText = "AAA-死粉-";
        //是否备注
        CheckDeadFriActivity.Accessibility.isRemarks = binding.radioRemark.isChecked();
        //是否删除
        CheckDeadFriActivity.Accessibility.isDelect = binding.radioDelect.isChecked();
        //开始检测下标
        CheckDeadFriActivity.Accessibility.checkBeginNum = checkBeginNum;
        //已经巡逻过的好友
        CheckDeadFriActivity.Accessibility.patrolList = new ArrayList<String>();
        //点进去检测的好友
        CheckDeadFriActivity.Accessibility.checkedList = new ArrayList<String>();
        //记录
        CheckDeadFriActivity.Accessibility.recordMap = new HashMap<>();
        //ListView position
        CheckDeadFriActivity.Accessibility.position = 0;
        //检测列表最后一项
        CheckDeadFriActivity.Accessibility.lastListItemTextMap = new HashMap<>();
        //删除人数
        CheckDeadFriActivity.Accessibility.delectNum = 0;
        //备注人数
        CheckDeadFriActivity.Accessibility.remarkNum = 0;
        //是否完成任务
        CheckDeadFriActivity.Accessibility.finished = false;
        //启动窗口
        AutomationAccessibilityService.mCrrentFunction = currentFunction;
        jumpWx();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //反注册
        binding.switchFloating.setOnCheckedChangeListener(null);
        binding.switchAccessibilityServices.setOnCheckedChangeListener(null);
        //设置默认值
        binding.switchFloating.setChecked(isDrawOverlays());
        binding.switchAccessibilityServices.setChecked(isServiceRunning(AutomationAccessibilityService.getAutomationAccessibilityService()));
        //注册回调
        initView();
    }

    public static class Accessibility extends AccessibilityUtils {

        private static final String TAG = "CheckDeadFriActivity";
        //发送信息
        public static String sendMsg = "软件正在自动好友检测,勿回复;";
        //备注信息
        public static String remarkText = "AAA-死粉-";
        //是否备注
        public static boolean isRemarks = false;
        //是否删除
        public static boolean isDelect = false;
        //开始检测下标
        public static int checkBeginNum = 0;
        //已经巡逻过的好友
        public static List<String> patrolList = new ArrayList<String>();
        //点进去检测的好友
        public static List<String> checkedList = new ArrayList<String>();
        //记录
        public static Map<String, String> recordMap = new HashMap<>();
        //ListView position
        public static Integer position = 0;
        //检测列表最后一项
        public static Map<String, Integer> lastListItemTextMap = new HashMap<>();
        //删除人数
        public static int delectNum = 0;
        //备注人数
        public static int remarkNum = 0;
        //是否完成任务
        public static boolean finished = false;

        //微信主界面 - 下面导航栏 (4个)
        public static String navigationBarId = "com.tencent.mm:id/cns";
        //微信主界面 - Title
        public static String titleId = "android:id/text1";

        //微信主界面 - 通讯录 - 联系人名字
        public static String contactsId = "com.tencent.mm:id/dy5";
        //微信主界面 - 通讯录 - 联系人总数
        public static String contactsTotalId = "com.tencent.mm:id/azb";

        //好友界面 - 发消息按钮
        public static String sendMessageId = "com.tencent.mm:id/g6f";
        //好友界面 - 微信号
        public static  String wechatNumberId = "com.tencent.mm:id/b2f";
        //好友界面 - 右上角详情
        public static String friendFunctionButtonId = "com.tencent.mm:id/cj";

        //聊天界面 名字
        public static String chatActivityNameId = "com.tencent.mm:id/gas";

        //聊天界面 输入框
        public static String chatActivityInputBoxId = "com.tencent.mm:id/al_";
        //聊天界面 发送按钮
        public static String chatActivitySendButtonId = "com.tencent.mm:id/anv";
        //聊天界面 红色小红点
        public static String chatActivityRedPointId = "com.tencent.mm:id/ao1";
        //聊天界面 右上角三个
        public static String chatActivityFunctionButtonId = "com.tencent.mm:id/cj";

        //聊天信息
        //聊天信息界面 名字
        public static String chatInfoActivityNameId = "com.tencent.mm:id/f3v";

        //
        public static String dialogItem = "com.tencent.mm:id/gam";

        //设置备注和标签 - 输入框
        public static String setNotesLabelsId = "com.tencent.mm:id/b0a";
        public static String setNotesLabelsSuccessfulButtonId = "com.tencent.mm:id/ch";

        //删除联系人弹窗确认
        public static String deleteFriendComfirmTitleId = "com.tencent.mm:id/dp0";
        //删除联系人弹窗确认 确认按钮
        public static String deleteFriendComfirmSuccessFulButtonId = "com.tencent.mm:id/doz";

        public static void in(AutomationAccessibilityService automationAccessibilityService, AccessibilityNodeInfo sourceNodeInfo) {
            Log.d(TAG, "CheckDeadFriActivity.in");
            AutomationAccessibilityService.mCrrentState =
                    "开始人数：" + checkBeginNum + " 操作：" + (isRemarks ? "备注" : "删除") +
                            "\n筛选人数：" + patrolList.size() +
                            "\n检测人数：" + checkedList.size() +
                            "\n备注人数：" + remarkNum +
                            "\n删除人数：" + delectNum +
                            "\n是否已经完成任务：" + (finished ? "是" : "否");

            if (!AutomationAccessibilityService.isRun) {
                return;
            }

            if (finished) {
                Log.d(TAG, "CheckDeadFriAccessibility.in - finished = " + finished);
                return;
            }

            //在微信主界面,但是不在通讯录界面
            List<AccessibilityNodeInfo> navigationBarNodeInfoList = findById(sourceNodeInfo, navigationBarId);
            AccessibilityNodeInfo titleNodeInfo = findById(sourceNodeInfo, titleId, 0);
            String titleNodeInfoText = findTextByNodeInfo(titleNodeInfo);
            if (navigationBarNodeInfoList != null && titleNodeInfoText != null && !"通讯录".equals(titleNodeInfoText)) {
                for (AccessibilityNodeInfo item : navigationBarNodeInfoList) {
                    String navigationBarNodeItemText = findTextByNodeInfo(item);
                    if (navigationBarNodeItemText != null && "通讯录".equals(navigationBarNodeItemText)) {
                        clickParentNode(item);
                        position = 0;
                        break;
                    }
                }
            }

            // 通讯录界面 找联系人
            List<AccessibilityNodeInfo> contactsNodeInfo = findById(sourceNodeInfo, contactsId);
            Log.d(TAG, "通讯录 - 找到联系人 ： " + (contactsNodeInfo == null ? "" : contactsNodeInfo.size()));
            if (contactsNodeInfo != null) {
                for (AccessibilityNodeInfo item : contactsNodeInfo) {
                    String paText = findTextByNodeInfo(item);
                    int i = patrolList.lastIndexOf(paText);
                    if (i == -1) {
                        Log.d(TAG, "通讯录 - 轮询到：" + paText + "没有被检查过 - 抓去检查");
                        patrolList.add(paText);
                        //从第几个好友开始
                        if (patrolList.size() >= checkBeginNum) {
                            //没有点击进去过的,现在点击
                            if (checkedList.lastIndexOf(paText) == -1) {
                                checkedList.add(paText);
                                clickParentNode(item);
                                break;
                            }
                        }
                    }

                    //最后一个人
                    if (contactsNodeInfo.size() - 1 == contactsNodeInfo.indexOf(item)) {
                        Log.d(TAG, "通讯录 - 检测到最后一人[" + paText + "] - 请求组织下一页");
                        //找到List
                        AccessibilityNodeInfo listNodeInfo = findListView(item);
                        if (listNodeInfo != null) {
                            boolean isSuitableScroll = isSuitableScroll(lastListItemTextMap, paText);
                            Log.d(TAG, "通讯录 - isSuitableScroll" + isSuitableScroll);
                            if (isSuitableScroll) {
                                //滑动
                                if (position == 0)
                                    position = contactsNodeInfo.size();
                                //滑
                                position = scrollListView(listNodeInfo, position);
                                Log.d(TAG, "通讯录 - position" + position);
                            } else {
                                //xxx位联系人
                                AccessibilityNodeInfo contactsTotaloNodeInfo = findById(sourceNodeInfo, contactsTotalId, 0);
                                if (contactsTotaloNodeInfo != null) {
                                    //滑动突破限制
                                    finished = true;
                                } else {
                                    lastListItemTextMap = new HashMap<>();
                                    finished = false;
                                }
                                Log.d(TAG, "通讯录 - b5oNodeInfo" + contactsTotaloNodeInfo);
                            }
                        }
                    }
                }
            }

            //好友详情页 - 发消息按钮 com.tencent.mm:id/d9
            AccessibilityNodeInfo sendMessageNodeInfo = findById(sourceNodeInfo, sendMessageId, 0);
            if (sendMessageNodeInfo != null) {
                String sendMessageNodeInfoText = findTextByNodeInfo(sendMessageNodeInfo);
                if (sendMessageNodeInfoText != null && sendMessageNodeInfoText.contains("发消息")) {
                    //微信号
                    String wechatNumberText = findTextByNodeInfo(findById(sourceNodeInfo, wechatNumberId, 0));
                    //没有记录
                    if (recordMap.get(wechatNumberText) == null) {
                        //第一次进入好友详情界面 点击发消息界面
                        clickParentNode(sendMessageNodeInfo);
                        recordMap.put(wechatNumberText, "once");
                    } else {
                        String s = recordMap.get(wechatNumberText);
                        if ("once".equals(s)) {
                            //点击详情
                            clickNode(findById(sourceNodeInfo, friendFunctionButtonId, 0));
                            recordMap.put(wechatNumberText, "two");
                        } else if ("two".equals(s)) {
                            back(automationAccessibilityService);
                        }
                    }

                }
            }

            //聊天界面 - 名字 com.tencent.mm:id/lt
            AccessibilityNodeInfo chatActivityNameNodeInfo = findById(sourceNodeInfo, chatActivityNameId, 0);
            if (chatActivityNameNodeInfo != null) {
                String chatActivityNameNodeInfoText = findTextByNodeInfo(chatActivityNameNodeInfo);
                Log.d(TAG, "找到聊天界面 微信用户：" + chatActivityNameNodeInfoText);
                if (chatActivityNameNodeInfoText != null && isRemarks && chatActivityNameNodeInfoText.contains(remarkText)) {
                    //已经备注好了的,直接返回
                    back(automationAccessibilityService);
                } else {// else if (checkedList.lastIndexOf(chatActivityNameNodeInfoText) != -1)
                    //这个人需要检查
                    //聊天界面 - 输入框 com.tencent.mm:id/aqe
                    AccessibilityNodeInfo chatActivityInputBoxdeInfo = findById(sourceNodeInfo, chatActivityInputBoxId, 0);
                    setTextByNodeInfo(chatActivityInputBoxdeInfo, sendMsg);
                    sleep(200);
                    //发送按钮
                    clickNode(findById(sourceNodeInfo, chatActivitySendButtonId, 0));
                    sleep(200);
                    //聊天界面 - 我方红色小按钮 com.tencent.mm:id/awf
                    List<AccessibilityNodeInfo> chatActivityRedPointNodeInfoList = findById(sourceNodeInfo, chatActivityRedPointId);
                    boolean isHaveRedSpot = false;
                    if (chatActivityRedPointNodeInfoList != null) {
                        if (chatActivityRedPointNodeInfoList.size() > 0) {
                            //存在小红点
                            isHaveRedSpot = true;
                        }
                    }
                    Log.d(TAG, "微信用户：" + chatActivityNameNodeInfoText + "\t " + (isHaveRedSpot ? "存在小红点" : "好友"));
                    if (isHaveRedSpot) {
                        //右上角
                        clickParentNode(findById(sourceNodeInfo, chatActivityFunctionButtonId, 0));
                    } else {
                        back(automationAccessibilityService);
                    }
                }
            }

            //非好友 好友详情界面
            if (titleNodeInfoText != null && "聊天信息".equals(titleNodeInfoText)) {
                //获取名字
                AccessibilityNodeInfo chatInfoActivityNameNodeInfo = findById(sourceNodeInfo, chatInfoActivityNameId, 0);
                String chatInfoActivityNameText = findTextByNodeInfo(chatInfoActivityNameNodeInfo);
                if (isRemarks && chatInfoActivityNameText.contains(remarkText)) {
                    //如果已经备注回来 直接返回即可
                    back(automationAccessibilityService);
                } else {
                    //点击进去名字的地方
                    clickParentNode(chatInfoActivityNameNodeInfo);
                }
            }

            //好友备注界面
            if (titleNodeInfoText != null && "设置备注和标签".equals(titleNodeInfoText)) {
                //输入框
                AccessibilityNodeInfo b_qNodeInfo = findById(sourceNodeInfo, setNotesLabelsId, 0);
                //+ findTextByNodeInfo(b_qNodeInfo)
                setTextByNodeInfo(b_qNodeInfo, remarkText);
                sleep(200);
                //完成
                remarkNum++;
                clickParentNode(findById(sourceNodeInfo, setNotesLabelsSuccessfulButtonId, 0));
            }


            //弹窗 备注或删除
            List<AccessibilityNodeInfo> dialogItemNodeInfos = findById(sourceNodeInfo, dialogItem);
            if (dialogItemNodeInfos != null) {
                for (AccessibilityNodeInfo item : dialogItemNodeInfos) {
                    if (isDelect && "删除".equals(findTextByNodeInfo(item))) {
                        clickParentNode(item);
                        break;
                    }
                    if (isRemarks && "设置备注和标签".equals(findTextByNodeInfo(item))) {
                        clickParentNode(item);
                        break;
                    }
                }
            }

            //删除好友弹窗
            AccessibilityNodeInfo deleteFriendComfirmTitleNodeInfo = findById(sourceNodeInfo, deleteFriendComfirmTitleId, 0);
            if (deleteFriendComfirmTitleNodeInfo != null) {
                String deleteFriendComfirmTitleText = findTextByNodeInfo(deleteFriendComfirmTitleNodeInfo);
                if ("删除联系人".equals(deleteFriendComfirmTitleText)) {
                    delectNum++;
                    clickParentNode(findById(sourceNodeInfo, deleteFriendComfirmSuccessFulButtonId, 0));
                }
            }


            boolean isNew = true;
            if (isNew)
                return;

        }
    }
}
