package com.example.automaticdemo.releaseui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;

import com.example.automaticdemo.R;
import com.example.automaticdemo.Service.AccessibilityUtils;
import com.example.automaticdemo.Service.AutomationAccessibilityService;
import com.example.automaticdemo.app.App;
import com.example.automaticdemo.base.BaseActivity;
import com.example.automaticdemo.databinding.ActivityGroupSendBinding;
import com.example.automaticdemo.util.ToastUtil;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.example.automaticdemo.releaseui.CheckDeadFriActivity.Accessibility.contactsTotalId;
import static com.example.automaticdemo.releaseui.GroupAddActivity.Accessibility.lastListItemTextMap;

public class GroupSendActivity extends BaseActivity {

    public static final String currentFunction = "图文群发";
    private ActivityGroupSendBinding binding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_group_send);
        setTitle(currentFunction);
        initView();
    }

    private void initView() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("发送给好友"));
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("发送给群聊"));
        binding.tabLayout.addOnTabSelectedListener(new TabLayout.BaseOnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (binding.tabLayout.getTabAt(0).isSelected()) {
                    binding.tvInstructions.setText("你可以选择只发送文字或图片给好友，也可以选择同时发送文字和图片给好友。");
                } else {
                    binding.tvInstructions.setText("自动发送消息到多个微信群，支持文字，连接，符号群发，默认发送通讯录中所有群聊。");
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    public void tvType1OnClick(View view) {
        binding.tvType1.setBackgroundResource(R.drawable.oval_empty);
        binding.tvType2.setBackgroundResource(0);
        binding.tvType3.setBackgroundResource(0);
        binding.llMessage.setVisibility(View.VISIBLE);
        binding.llPic.setVisibility(View.GONE);
    }

    public void tvType2OnClick(View view) {
        binding.tvType1.setBackgroundResource(0);
        binding.tvType2.setBackgroundResource(R.drawable.oval_empty);
        binding.tvType3.setBackgroundResource(0);
        binding.llMessage.setVisibility(View.GONE);
        binding.llPic.setVisibility(View.VISIBLE);
    }

    public void tvType3OnClick(View view) {
        binding.tvType1.setBackgroundResource(0);
        binding.tvType2.setBackgroundResource(0);
        binding.tvType3.setBackgroundResource(R.drawable.oval_empty);
        binding.llMessage.setVisibility(View.VISIBLE);
        binding.llPic.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //反注册
        binding.switchFloating.setOnCheckedChangeListener(null);
        binding.switchAccessibilityServices.setOnCheckedChangeListener(null);
        //设置默认值
        binding.switchFloating.setChecked(isDrawOverlays());
        binding.switchAccessibilityServices.setChecked(isServiceRunning(AutomationAccessibilityService.getAutomationAccessibilityService()));
        //注册回调
        binding.switchFloating.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getOverlayPermission();
            }
        });

        binding.switchAccessibilityServices.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                openAccessibilityServiceSettings(GroupSendActivity.this);
            }
        });

        if (GroupSendActivity.Accessibility.patrolGroupList != null && GroupSendActivity.Accessibility.patrolGroupList.size() != 0) {
            for (String item : GroupSendActivity.Accessibility.patrolGroupList) {
                TextView textView = new TextView(this);
                textView.setPadding(16,8,16,8);
                textView.setText(item);
                textView.setTextSize(16);
//                textView.setBackgroundResource(R.drawable.s);
                binding.groupCheckFlowLayout.addView(textView);
            }
        }


    }

    public void btnOnClick(View view) {
        //服务逻辑已经写好
        if (!(binding.switchFloating.isChecked() && binding.switchAccessibilityServices.isChecked())) {
            Toast.makeText(App.getContext(), "权限设置没有打开,请打开", Toast.LENGTH_SHORT).show();
            return;
        }
        //检测群聊数量
        GroupSendActivity.Accessibility.accessibilityType = 1;
        //初始化参数
        //发送信息
        CheckDeadFriActivity.Accessibility.sendMsg = "软件正在自动好友检测,勿回复;";
        //启动窗口
        AutomationAccessibilityService.mCrrentFunction = currentFunction;
        jumpWx();
    }

    public static class Accessibility extends AccessibilityUtils {

        private static final String TAG = "CheckDeadFriActivity";

        //开始检测下标
        public static int checkBeginNum = 0;
        //ListView position
        public static Integer position = 0;
        //已经巡逻过的群
        public static List<String> patrolGroupList = new ArrayList<String>();


        //微信主界面 - 下面导航栏 (4个)
        public static String navigationBarId = "com.tencent.mm:id/cns";
        //微信主界面 - Title
        public static String titleId = "android:id/text1";
        //微信主界面 - 通讯录 - 群聊
        public static String groupItemId = "com.tencent.mm:id/fx";
        //微信主界面 - 通讯录 - 群聊 - (群名字Item_tv)
        public static String groupActivityListItemTvId = "com.tencent.mm:id/b32";
        //微信主界面 - 通讯录 - 群聊 - 最下面群聊数量
        public static String groupActivityListItemTotalTvId = "com.tencent.mm:id/azb";

        //


        //


        private static int accessibilityType = 0;

        /**
         * 检测所有群组
         *
         * @param automationAccessibilityService
         * @param sourceNodeInfo
         */
        public static synchronized void checkGroup(AutomationAccessibilityService automationAccessibilityService, AccessibilityNodeInfo sourceNodeInfo) {
            Log.d(TAG, "图文群发 - 群聊检测");
            if (accessibilityType != 1) {
                return;
            }
            //不采用finish方式结束  直接使用accessibilityType != 1

            //在微信主界面,但是不在通讯录界面
            List<AccessibilityNodeInfo> navigationBarNodeInfoList = findById(sourceNodeInfo, navigationBarId);
            AccessibilityNodeInfo titleNodeInfo = findById(sourceNodeInfo, titleId, 0);
            String titleNodeInfoText = findTextByNodeInfo(titleNodeInfo);
            if (navigationBarNodeInfoList != null && titleNodeInfoText != null && !"通讯录".equals(titleNodeInfoText)) {
                for (AccessibilityNodeInfo item : navigationBarNodeInfoList) {
                    String navigationBarNodeItemText = findTextByNodeInfo(item);
                    if (navigationBarNodeItemText != null && "通讯录".equals(navigationBarNodeItemText)) {
                        clickParentNode(item);
                        return;
                    }
                }
            }

            //找到群聊Item按钮
            List<AccessibilityNodeInfo> groupItemNodeInfoList = findById(sourceNodeInfo, groupItemId);
            if (groupItemNodeInfoList != null) {
                for (AccessibilityNodeInfo item : groupItemNodeInfoList) {
                    String groupItemNodeInfoListItemText = findTextByNodeInfo(item);
                    if ("群聊".equals(groupItemNodeInfoListItemText)) {
                        clickParentNode(item);
                        return;
                    }
                }
            }

            //当前是群聊保存界面
            if ("群聊".equals(titleNodeInfoText)) {
                //群聊界面 - 群聊联系人
                List<AccessibilityNodeInfo> groupActivityListItemTvNodeInfo = findById(sourceNodeInfo, groupActivityListItemTvId);
                Log.d(TAG, "通讯录 - 找到群聊 ： " + (groupActivityListItemTvNodeInfo == null ? "" : groupActivityListItemTvNodeInfo.size()));
                if (groupActivityListItemTvNodeInfo != null) {
                    for (AccessibilityNodeInfo item : groupActivityListItemTvNodeInfo) {
                        String groupActivityListItemTvNodeInfoText = findTextByNodeInfo(item);
                        boolean patrolGroupContains = patrolGroupList.contains(groupActivityListItemTvNodeInfoText);
                        if (patrolGroupContains == false) {
                            patrolGroupList.add(groupActivityListItemTvNodeInfoText);
                        }
                        //最后一个人
                        if (groupActivityListItemTvNodeInfo.size() - 1 == groupActivityListItemTvNodeInfo.indexOf(item)) {
                            Log.d(TAG, "通讯录 - 检测到最后一群组 [" + patrolGroupContains + "] - 请求组织下一页");
                            //找到List
                            AccessibilityNodeInfo listNodeInfo = findListView(item);
                            if (listNodeInfo != null) {
                                //滑动成功
                                position = scrollListView(listNodeInfo, position);
                                Log.d(TAG, "通讯录 - 检测到最后一群组 已滑动成功【" + position + "】");
                            }
                        }
                    }
                }
            }

            //找到全部群聊数量
            AccessibilityNodeInfo groupActivityListItemTotalTvNodeInfo = findById(sourceNodeInfo, groupActivityListItemTotalTvId, 0);
            if (groupActivityListItemTotalTvNodeInfo != null) {
                String groupActivityListItemTotalTvNodeInfoText = findTextByNodeInfo(groupActivityListItemTotalTvNodeInfo);
                if (groupActivityListItemTotalTvNodeInfoText != null && groupActivityListItemTotalTvNodeInfoText.contains("个群聊")) {
                    groupActivityListItemTotalTvNodeInfoText = groupActivityListItemTotalTvNodeInfoText.replace("个群聊", "");
                    Log.d(TAG, "通讯录 - 检测群聊完毕 群信群聊共【" + groupActivityListItemTotalTvNodeInfoText + "】 检测【" + patrolGroupList.size() + "】");
                    //回到自己软件
//                    Intent intent = new Intent(App.getContext(), GroupSendActivity.class);
//                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                    App.getContext().startActivity(intent);
                }
            }

            //groupActivityListItemTotalTvId


        }

        public static synchronized void in(AutomationAccessibilityService automationAccessibilityService, AccessibilityNodeInfo sourceNodeInfo) {
            if (accessibilityType == 1) checkGroup(automationAccessibilityService, sourceNodeInfo);
        }
    }

}
