package com.example.automaticdemo.Service;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.BounceInterpolator;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.automaticdemo.R;
import com.example.automaticdemo.app.App;
import com.example.automaticdemo.releaseui.CheckDeadFriActivity;
import com.example.automaticdemo.releaseui.GroupAddActivity;
import com.example.automaticdemo.releaseui.GroupSendActivity;
import com.yhao.floatwindow.FloatWindow;
import com.yhao.floatwindow.MoveType;
import com.yhao.floatwindow.Screen;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AutomationAccessibilityService extends AccessibilityService {

    public static final String ServiceLastTimeKey = "ServiceLastTimeKey";

    private static final String TAG = "AccessibilityService";

    public static String mCrrentFunction = "";
    public static String mCrrentState = "";

    private static AutomationAccessibilityService automationAccessibilityService;
    private static View floatWindowView;

    public static AutomationAccessibilityService getAutomationAccessibilityService() {
        return automationAccessibilityService;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "connected");
        automationAccessibilityService = this;
//        showFloatWindow();
    }

    public void recycle(AccessibilityNodeInfo info) {
        if (info.getChildCount() == 0) {
            Log.i(TAG, "class ----------------------------" + info.getClassName());
            Log.i(TAG, "text " + info.getText());
            Log.i(TAG, "resource-id  " + info.getViewIdResourceName());
            Log.i(TAG, "showDialog:" + info.canOpenPopup());
            Log.i(TAG, "windowId:" + info.getWindowId());
        } else {
            for (int i = 0; i < info.getChildCount(); i++) {
                if (info.getChild(i) != null) {
                    recycle(info.getChild(i));
                }
            }
        }
    }

    long eventLastTime = 0;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        Log.d(TAG, "onAccessibilityEvent");
        //更新浮悬窗
        mHandler.sendMessage(new Message());
        AccessibilityNodeInfo rootInActiveWindow = getRootInActiveWindow();
        if (rootInActiveWindow == null) {
            Log.d(TAG, "rootInActiveWindow == null");
            return;
        }

        long currTime = System.currentTimeMillis();
        if (!(eventLastTime + 1000 < currTime)) {
            Log.d(TAG, "!(eventLastTime + 1000 < currTime)");
            return;
        }
        eventLastTime = currTime;
        recycle(rootInActiveWindow);

        //当前界面的可访问节点信息
        AccessibilityNodeInfo sourceNodeInfo = accessibilityEvent.getSource();
        switch (mCrrentFunction) {
            case CheckDeadFriActivity.currentFunction://检测死粉
                showFloatWindow();
                CheckDeadFriActivity.Accessibility.in(this, rootInActiveWindow);
                break;
            case GroupAddActivity.currentFunction://群内加人
                showFloatWindow();
                GroupAddActivity.Accessibility.in(this, rootInActiveWindow);
                break;
            case GroupSendActivity.currentFunction://图文群发
                showFloatWindow();
                GroupSendActivity.Accessibility.in(this, rootInActiveWindow);
                break;
//            case GroupSendActivity.currentFunction://群发助手
//                showFloatWindow();
//                GroupSendAccessibility.in(this, sourceNodeInfo);
//                break;
//            case NearbyAddActivity.currentFunction://附近加人
//                showFloatWindow();
//                NearbyAddActivity.Accessibility.in(this, rootInActiveWindow);
//                break;
//            case SilenceCheckDeadFri.currentFunction://静默检测死粉
//                showFloatWindow();
//                SilenceCheckDeadFri.Accessibility.in(this, rootInActiveWindow);
//                break;
            default:
                hideFloatWindow();
                break;
        }
    }

    public static boolean isRun = false;

    public static void showFloatWindow() {
        //全局唯一w问题
        if (FloatWindow.get(TAG) == null) {
            floatWindowView = View.inflate(App.getContext(), R.layout.floatwindow, null);
            FloatWindow.with(App.getContext())
                    .setView(floatWindowView)
                    .setWidth(570)
                    .setHeight(550)
                    .setX(Screen.width, 0.2f)
                    .setY(Screen.height, 0.25f)
                    .setTag(TAG)
                    .setMoveType(MoveType.slide)
                    .setMoveStyle(500, new BounceInterpolator())
                    .setDesktopShow(true)
                    .build();
            floatWindowView.findViewById(R.id.btn).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isRun = !isRun;
                    ((TextView) floatWindowView.findViewById(R.id.btn)).setText(isRun ? "停止" : "开始");
                }
            });
        } else {
            FloatWindow.get(TAG).show();
        }
    }

    public static void hideFloatWindow() {
        if (FloatWindow.get(TAG) != null)
            FloatWindow.get(TAG).hide();
    }

    private static Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            if (floatWindowView != null) {
                //获取服务最后时间
                ((TextView) floatWindowView.findViewById(R.id.tvLastTime)).setText("服务最后通讯时间：" + new SimpleDateFormat("HH:mm:ss").format(new Date(System.currentTimeMillis())));
                ((TextView) floatWindowView.findViewById(R.id.tvCrrentFunction)).setText("当前功能：" + AutomationAccessibilityService.mCrrentFunction + (isRun ? "-运行中" : "-停止"));
                ((TextView) floatWindowView.findViewById(R.id.tvState)).setText(AutomationAccessibilityService.mCrrentState);
            }
        }
    };

    @Override
    public void onInterrupt() {
        Log.d(TAG, "onInterrupt");
    }

}
