package com.example.automaticdemo.util;

import android.widget.Toast;

import com.example.automaticdemo.app.App;


/**
 * 自定义Toast工具类,防止用户快速操作导致Dialog多次显示
 */
public class ToastUtil {

    private static Toast mToast;

    public static void show(String text) {
        if (StringUtil.isNullOrEmpty(text))
            return;
        if (mToast != null) {
            mToast.setText(text);
        } else {
            mToast = Toast.makeText(App.getContext(), text, Toast.LENGTH_SHORT);
        }
        mToast.show();
    }
}