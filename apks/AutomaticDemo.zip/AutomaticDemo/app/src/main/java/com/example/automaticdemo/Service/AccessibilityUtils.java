package com.example.automaticdemo.Service;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.util.Log;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Map;

public class AccessibilityUtils {


    public static final int DefaultMillis = 1000;
    public static final int SetEtTextMillis = 1500;
    public static final int ScrollSleepMillis = 400;
    public static final int CheckBoxSelectSleepMillis = 200;


    public static long lastScrollTime = 0;


    /**
     * 根据子界面返回上级ListView
     *
     * @param nodeInfo 可为ListView Item 中 元素
     * @return
     */
    public static AccessibilityNodeInfo findListView(AccessibilityNodeInfo nodeInfo) {
        if (nodeInfo != null)
            if ("android.widget.ListView".equals(nodeInfo.getClassName())) {
                return nodeInfo;
            } else if ("android.widget.GridView".equals(nodeInfo.getClassName())) {
                return nodeInfo;
            } else {
                return findListView(nodeInfo.getParent());
            }
        else
            return null;
    }


    /**
     * 滑动List
     *
     * @param listNodeInfo ListView
     * @param position     当前记录
     * @return
     */
    public static Integer scrollListView(AccessibilityNodeInfo listNodeInfo, Integer position) {
        if (listNodeInfo == null) return position;
        position += 6;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            Bundle argument = new Bundle();
            argument.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_ROW_INT, position);
            boolean b = listNodeInfo.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION.getId(), argument);
        } else {
            if (System.currentTimeMillis() > lastScrollTime + 500) {
                lastScrollTime = System.currentTimeMillis();
                boolean b = listNodeInfo.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
            }
        }
        return position;
    }

    /**
     * 是否能滑
     *
     * @param lastListItemTextMap lastListItemTextMap
     * @param itemKey             最后ItemKey
     * @return
     */
    public static boolean isSuitableScroll(Map<String, Integer> lastListItemTextMap, String itemKey) {
        //每次滑动记录Item
        if (lastListItemTextMap.get(itemKey) == null) {
            lastListItemTextMap.put(itemKey, 1);
        } else {
            Integer integer = lastListItemTextMap.get(itemKey);
            integer = integer == null ? 1 : (integer + 1);
            lastListItemTextMap.put(itemKey, integer);
        }
        //判断滑动
        if (lastListItemTextMap.get(itemKey) == null || lastListItemTextMap.get(itemKey) < 15) {
            //当最后一项检查少于15次 还可以允许滑动
            return true;
        } else {
            return false;
        }
    }

    /**
     * 睡眠
     *
     * @param millis
     */
    public static void sleep(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException mE) {
            mE.printStackTrace();
        }
    }

    public static List<AccessibilityNodeInfo> findById(AccessibilityNodeInfo sourceNodeInfo, String id) {
        if (sourceNodeInfo == null) return null;
        List<AccessibilityNodeInfo> nodeInfos = sourceNodeInfo.findAccessibilityNodeInfosByViewId(id);
        return nodeInfos;
    }

    public static String subString(String str, String strStart, String strEnd) {
        /* 找出指定的2个字符在 该字符串里面的 位置 */
        int strStartIndex = str.indexOf(strStart);
        int strEndIndex = str.indexOf(strEnd);
        /* index 为负数 即表示该字符串中 没有该字符 */
        if (strStartIndex < 0) {
            return null;
        }
        if (strEndIndex < 0) {
            return null;
        }
        /* 开始截取 */
        String result = str.substring(strStartIndex, strEndIndex).substring(strStart.length());
        return result;
    }

    public static AccessibilityNodeInfo findById(AccessibilityNodeInfo sourceNodeInfo, String id, int position) {
        if (sourceNodeInfo == null) return null;
        List<AccessibilityNodeInfo> nodeInfos = sourceNodeInfo.findAccessibilityNodeInfosByViewId(id);
        if (nodeInfos == null || !(nodeInfos.size() > position)) return null;
        return nodeInfos.get(position);
    }

    public static String findTextByNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null || accessibilityNodeInfo.getText() == null) return null;
        return accessibilityNodeInfo.getText().toString().trim();
    }

    public static void setTextByNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo, String message) {
        if (accessibilityNodeInfo == null) return;
        Bundle arguments = new Bundle();
        arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message);
        accessibilityNodeInfo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
        return;
    }


    public static void back(AutomationAccessibilityService automationAccessibilityService) {
        automationAccessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
        return;
    }

    public static void goHome(AutomationAccessibilityService automationAccessibilityService) {
        automationAccessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
        return;
    }


    /**
     * 点击匹配的nodeInfo
     *
     * @param str text关键字
     */
    public static void openNext(AutomationAccessibilityService automationAccessibilityService, String str) {
        AccessibilityNodeInfo nodeInfo = automationAccessibilityService.getRootInActiveWindow();
        if (nodeInfo == null) {
            return;
        }
        List<AccessibilityNodeInfo> list = nodeInfo.findAccessibilityNodeInfosByText(str);
        Log.d("name", "匹配个数: " + list.size());
        if (list.size() > 0) {
            list.get(list.size() - 1).performAction(AccessibilityNodeInfo.ACTION_CLICK);
            list.get(list.size() - 1).getParent().performAction(AccessibilityNodeInfo.ACTION_CLICK);
        }
    }

    public static void clickNode(AccessibilityNodeInfo nodeInfo) {
        if (nodeInfo != null)
            nodeInfo.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    public static void clickParentNode(AccessibilityNodeInfo nodeInfo) {
        if (nodeInfo != null)
            if (nodeInfo.isClickable()) {
                nodeInfo.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            } else {
                clickParentNode(nodeInfo.getParent());
            }
    }

}
