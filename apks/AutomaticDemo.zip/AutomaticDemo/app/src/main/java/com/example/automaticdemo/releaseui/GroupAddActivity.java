package com.example.automaticdemo.releaseui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.databinding.DataBindingUtil;

import com.example.automaticdemo.R;
import com.example.automaticdemo.Service.AccessibilityUtils;
import com.example.automaticdemo.Service.AutomationAccessibilityService;
import com.example.automaticdemo.app.App;
import com.example.automaticdemo.base.BaseActivity;
import com.example.automaticdemo.databinding.ActivityGroupaddBinding;
import com.example.automaticdemo.util.StringUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupAddActivity extends BaseActivity {

    public static final String currentFunction = "群内加人";

    private ActivityGroupaddBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_groupadd);
        setTitle(currentFunction);
        initView();
        binding.tvAddNum.setText("选择添加人数：" + binding.seekBar.getProgress());
    }

    public void initView() {
        binding.switchFloating.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getOverlayPermission();
            }
        });

        binding.switchAccessibilityServices.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                openAccessibilityServiceSettings(GroupAddActivity.this);
            }
        });
        binding.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                binding.tvAddNum.setText("选择添加人数：" + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public void tvRecommend1OnClick(View view) {
        binding.etMessage.setText(binding.tvRecommend1.getText());
    }

    public void tvRecommend2OnClick(View view) {
        binding.etMessage.setText(binding.tvRecommend2.getText());
    }

    public void tvRecommend3OnClick(View view) {
        binding.etMessage.setText(binding.tvRecommend3.getText());
    }

    public void tvRecommend4OnClick(View view) {
        binding.etMessage.setText(binding.tvRecommend4.getText());
    }

    public void btnOnClick(View view) {
        if (!(binding.switchFloating.isChecked() && binding.switchAccessibilityServices.isChecked())) {
            Toast.makeText(App.getContext(), "权限设置没有打开,请打开", Toast.LENGTH_SHORT).show();
            return;
        }
        if (binding.etMessage.getText() == null || binding.etMessage.getText().toString() == null) {
            Toast.makeText(App.getContext(), binding.etMessage.getHint().toString().trim(), Toast.LENGTH_SHORT).show();
            return;
        }

        //申请信息
        GroupAddActivity.Accessibility.msg = binding.etMessage.getText().toString();
        //加男加女
        GroupAddActivity.Accessibility.settingSex = binding.radioButton1.isChecked() ? "男女" : GroupAddActivity.Accessibility.settingSex;
        GroupAddActivity.Accessibility.settingSex = binding.radioButton2.isChecked() ? "女" : GroupAddActivity.Accessibility.settingSex;
        GroupAddActivity.Accessibility.settingSex = binding.radioButton3.isChecked() ? "男" : GroupAddActivity.Accessibility.settingSex;
        //添加人数
        GroupAddActivity.Accessibility.settintAddNum = binding.seekBar.getProgress();
        //点进去检测的好友
        GroupAddActivity.Accessibility.checkedMap = new ArrayList<String>();
        //记录
        GroupAddActivity.Accessibility.recordMap = new HashMap<>();
        //群人数
        GroupAddActivity.Accessibility.groupNum = 0;
        //已经发送申请信息人数
        GroupAddActivity.Accessibility.sendMsgCount = 0;
        //是否完成
        GroupAddActivity.Accessibility.finished = false;
        //ListView position
        GroupAddActivity.Accessibility.position = 0;
        //检测列表最后一项
        GroupAddActivity.Accessibility.lastListItemTextMap = new HashMap<>();
        //启动
        AutomationAccessibilityService.mCrrentFunction = currentFunction;
        jumpWx();

    }

    @Override
    protected void onResume() {
        super.onResume();
        //反注册
        binding.switchFloating.setOnCheckedChangeListener(null);
        binding.switchAccessibilityServices.setOnCheckedChangeListener(null);
        //设置默认值
        binding.switchFloating.setChecked(isDrawOverlays());
        binding.switchAccessibilityServices.setChecked(isServiceRunning(AutomationAccessibilityService.getAutomationAccessibilityService()));
        //注册回调
        initView();
    }

    public static class Accessibility extends AccessibilityUtils {

        private static final String TAG = "GroupAddActivity";
        //申请信息
        public static String msg = "";
        //加男加女
        public static String settingSex = "男女";
        //添加人数
        public static int settintAddNum = 0;
        //点进去检测的好友
        public static List<String> checkedMap = new ArrayList<String>();
        //记录
        public static Map<String, String> recordMap = new HashMap<>();
        //群人数
        public static int groupNum = 0;
        //已经发送申请信息人数
        public static int sendMsgCount = 0;
        //是否完成
        public static boolean finished = false;
        //ListView position
        public static Integer position = 0;
        //检测列表最后一项
        public static Map<String, Integer> lastListItemTextMap = new HashMap<>();

        public static boolean isAddActivity = false;

        //微信主界面 - 下面导航栏 (4个)
        public static String navigationBarId = "com.tencent.mm:id/cns";
        //微信主界面 - Title
        public static String titleId = "android:id/text1";

        public static synchronized void in(AutomationAccessibilityService automationAccessibilityService, AccessibilityNodeInfo sourceNodeInfo) {

            Log.d(TAG, "GroupAddActivity.in");
            AutomationAccessibilityService.mCrrentState =
                    "群人数：" + groupNum +
                            "\n设置添加人数：" + settintAddNum +
                            "\n设置添加性别：" + settingSex +
                            "\n检测人数：" + checkedMap.size() +
                            "\n添加人数：" + sendMsgCount +
                            "\n是否已经完成任务：" + (finished ? "是" : "否");

            if (!AutomationAccessibilityService.isRun) {
                return;
            }

            if (sendMsgCount >= settintAddNum) {
                finished = true;
            }

            //20容错率
            if (groupNum > 0 && checkedMap.size() + 20 >= groupNum) {
                finished = true;
            }

            if (finished) {
                Log.d(TAG, "群添加好友功能已经完成");
                return;
            }

            //聊天界面 名字
            String chatActivityNameId = "com.tencent.mm:id/gas";
            //聊天界面 多功能按钮
            String chatActivityToolButtonId = "com.tencent.mm:id/cj";

            //微信主界面 - Title( 群详情标题 )
            String titleId = "android:id/text1";

            //聊天信息
            //每个人Name
            String chatInformaticaItemNameId = "com.tencent.mm:id/f3v";
            //List
            String chatInformationListId = "android:id/list";
            //查看全部成员
            String chatInformationMoreId = "android:id/title";

            //聊天成员界面
            String moreChatInformaticaItemNameId = "com.tencent.mm:id/f_l";

            //好友详情界面
            //发消息 添加通讯录 按钮
            String sendMessageId = "com.tencent.mm:id/g6f";
            //昵称 微信号 地区
            String sendMessageNickNameId = "com.tencent.mm:id/b27";
            String sendMessageWecharNumId = "com.tencent.mm:id/b2f";
            String sendMessageAreaId = "com.tencent.mm:id/b26";
            String sendMessageSexId = "com.tencent.mm:id/b2c";

            //添加好友
            String addFriTitleId = "com.tencent.mm:id/gam";
            String addFriMessageEditId = "com.tencent.mm:id/f5e";
            String addFriSuccessButtonId = "com.tencent.mm:id/ch";

            //弹窗
            String dialogTitleId = "com.tencent.mm:id/dp0";
            String dialogButtonId = "com.tencent.mm:id/doz";


            //在聊天界面 进入聊天界面  点击多功能按钮 获取人数
            AccessibilityNodeInfo chatActivityNameNodeInfo = findById(sourceNodeInfo, chatActivityNameId, 0);
            if (chatActivityNameNodeInfo != null) {
                String chatActivityNameText = findTextByNodeInfo(chatActivityNameNodeInfo);
                Log.d(TAG, "找到群 - " + chatActivityNameText);
                if (!"".equals(chatActivityNameText)) {
                    String s = subString(chatActivityNameText, "(", ")");
                    try {
                        groupNum = Integer.parseInt(s);
                    } catch (Exception e) {
                        groupNum = 0;
                    }
                    Log.d(TAG, "分析到群 - " + chatActivityNameText + " - 人数 - " + groupNum);
                    if (groupNum > 0) {
                        clickParentNode(findById(sourceNodeInfo, chatActivityToolButtonId, 0));
                    }
                }
            }


            //群聊详情 android:id/text1 聊天信息(462) - 获取人数
            AccessibilityNodeInfo titleNodeInfo = findById(sourceNodeInfo, titleId, 0);
            if (titleNodeInfo != null) {
                String titleNodeText = findTextByNodeInfo(titleNodeInfo);
                if (titleNodeText != null && !"".equals(titleNodeText) && ("聊天信息".contains(titleNodeText) || "聊天成员".contains(titleNodeText))) {
                    String s = subString(titleNodeText, "(", ")");
                    try {
                        groupNum = Integer.parseInt(s);
                    } catch (Exception e) {
                        groupNum = 0;
                    }
                }
            }

            //名字 com.tencent.mm:id/ej_ 寻找所有名字TextView
            List<AccessibilityNodeInfo> chatInformaticaItemNameNodeInfo = findById(sourceNodeInfo, chatInformaticaItemNameId);
            //遍历所有名字
            if (chatInformaticaItemNameNodeInfo != null) {
                Log.d(TAG, "群详情界面 - ListSize:【" + chatInformaticaItemNameNodeInfo.size() + "】");
                for (AccessibilityNodeInfo item : chatInformaticaItemNameNodeInfo) {
                    boolean isDo = false;
                    String chatInformaticaItemNameText = findTextByNodeInfo(item);
                    Log.d(TAG, "群详情界面 - 检测名字【" + chatInformaticaItemNameText + "】");
                    if (StringUtil.isNullOrEmpty(chatInformaticaItemNameText) == false) {
                        if (checkedMap.contains(chatInformaticaItemNameText) == false) {
                            //没有检查过的好友 点进去
                            checkedMap.add(chatInformaticaItemNameText);
                            clickParentNode(item);
                            Log.d(TAG, "群详情界面 - 进去【" + chatInformaticaItemNameText + "】 进行任务");
                            isDo = true;
                            break;
                        }
                    }
                    //最后一个人
                    if (chatInformaticaItemNameNodeInfo.size() - 1 == chatInformaticaItemNameNodeInfo.indexOf(item)) {
                        Log.d(TAG, "群详情界面 - 当前页已经检查完,请求组织下一页");
                        //全部成员
                        AccessibilityNodeInfo chatInformationMoreInfo = findById(sourceNodeInfo, chatInformationMoreId, 0);
                        //列表
                        AccessibilityNodeInfo listNodeInfo = findById(sourceNodeInfo, chatInformationListId, 0);
                        if (chatInformationMoreInfo != null) {
                            String chatInformationMoreText = findTextByNodeInfo(chatInformationMoreInfo);
                            Log.d(TAG, "群详情界面已到底部 - 查看全部成员按钮 ：【" + chatInformationMoreText + "】");
                            if (StringUtil.isNullOrEmpty(chatInformationMoreText) == false && "查看全部群成员".equals(chatInformationMoreText)) {
                                Log.d(TAG, "群详情界面已到底部 - 查看全部成员按钮 ：【点击】");
                                clickParentNode(chatInformationMoreInfo);
                            }
                        } else if (listNodeInfo != null) {
                            boolean b = listNodeInfo.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
                            Log.d(TAG, "群详情界面 - 当前页已经检查完 ListView 滑动 " + b);
                        }
                    }
                    if (isDo)
                        return;
                }
            }

            //全部群成员界面 名字 com.tencent.mm:id/azd 寻找所有名字TextView
            List<AccessibilityNodeInfo> moreChatInformaticaItemNameNodeInfo = findById(sourceNodeInfo, moreChatInformaticaItemNameId);
            //遍历所有名字
            if (moreChatInformaticaItemNameNodeInfo != null) {
                Log.d(TAG, "全部群成员界面 - ListSize:【" + chatInformaticaItemNameNodeInfo.size() + "】");
                boolean isDo = false;
                for (AccessibilityNodeInfo item : moreChatInformaticaItemNameNodeInfo) {
                    String moreChatInformaticaItemNameNodeInfoText = findTextByNodeInfo(item);
                    Log.d(TAG, "群详情界面 - 检测名字【" + moreChatInformaticaItemNameNodeInfoText + "】");
                    if (StringUtil.isNullOrEmpty(moreChatInformaticaItemNameNodeInfoText) == false) {
                        if (checkedMap.contains(moreChatInformaticaItemNameNodeInfoText) == false) {
                            //没有检查过的好友 点进去
                            checkedMap.add(moreChatInformaticaItemNameNodeInfoText);
                            clickParentNode(item);
                            Log.d(TAG, "群全部成员界面 - 进去【" + moreChatInformaticaItemNameNodeInfoText + "】 进行任务");
                            isDo = true;
                            break;
                        }
                    }
                    //最后一个人
                    if (moreChatInformaticaItemNameNodeInfo.size() - 1 == moreChatInformaticaItemNameNodeInfo.indexOf(item)) {
                        Log.d(TAG, "全部群成员界面 - 当前页已经检查完,请求组织下一页");
                        //列表
                        AccessibilityNodeInfo listNodeInfo = findListView(item);
                        if (listNodeInfo != null) {
                            boolean b = listNodeInfo.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
                            Log.d(TAG, "群详情界面 - 当前页已经检查完 ListView 滑动 " + b);
                        }
                    }
                    if (isDo)
                        return;
                }
            }

            //好友详情界面 添加到通讯录 发消息
            AccessibilityNodeInfo sendMessageNodeInfo = findById(sourceNodeInfo, sendMessageId, 0);
            if (sendMessageNodeInfo != null) {
                String sendMessageText = findTextByNodeInfo(sendMessageNodeInfo);
                sleep(300);
                if ("发消息".equals(sendMessageText)) {
                    back(automationAccessibilityService);
                } else if ("添加到通讯录".equals(sendMessageText)) {
                    if (isAddActivity){
                        isAddActivity = false;
                        back(automationAccessibilityService);
                        return;
                    }
                    String sexStr = null;
                    AccessibilityNodeInfo sendMessageSexNodeInfo = findById(sourceNodeInfo, sendMessageSexId, 0);
                    if (sendMessageSexNodeInfo != null) {
                        CharSequence sex = sendMessageSexNodeInfo.getContentDescription();
                        sexStr = sex != null ? sex.toString().trim() : null;
                    }
                    if (sexStr  != null && settingSex.contains(sexStr)){
                        clickParentNode(sendMessageNodeInfo);
                    }else {
                        back(automationAccessibilityService);
                    }

//                    String sendMessageNickNameText = findTextByNodeInfo(findById(sourceNodeInfo, sendMessageNickNameId, 0));
//                    String sendMessageWecharNumText = findTextByNodeInfo(findById(sourceNodeInfo, sendMessageWecharNumId, 0));
//                    String sendMessageAreaText = findTextByNodeInfo(findById(sourceNodeInfo, sendMessageAreaId, 0));
//                    String recordMapKey = sendMessageNickNameText + sendMessageWecharNumText + sendMessageAreaText + sexStr;
//                    Log.d(TAG, "好友界面：Key【" + recordMapKey + "】");
//                    String recordMapValue = recordMap.get(recordMapKey);
//                    if (recordMapValue == null && sexStr == null && "男女".equals(settingSex)) {
//                        clickParentNode(sendMessageNodeInfo);
//                        recordMap.put(recordMapKey, "in");
//                    } else if (recordMapValue == null && sexStr != null && settingSex.contains(sexStr)) {
//                        //包含所选择的性别
//                        clickParentNode(sendMessageNodeInfo);
//                        recordMap.put(recordMapKey, "in");
//                    } else if ("in".equals(recordMapValue)) {
//                        back(automationAccessibilityService);
//                    } else {
//                        back(automationAccessibilityService);
//                    }
                }
            }

            //申请添加朋友
            AccessibilityNodeInfo addFriTitleNodeInfo = findById(sourceNodeInfo, addFriTitleId, 0);
            if (addFriTitleNodeInfo != null) {
                String addFriTitleText = findTextByNodeInfo(addFriTitleNodeInfo);
                if (addFriTitleText != null && StringUtil.isNullOrEmpty(addFriTitleText) == false && "申请添加朋友".equals(addFriTitleText)) {
                    isAddActivity = true;
                    //申请内容
                    AccessibilityNodeInfo ejgNodeInfo = findById(sourceNodeInfo, addFriMessageEditId, 0);
                    setTextByNodeInfo(ejgNodeInfo, msg);
                    sleep(SetEtTextMillis);
                    sendMsgCount++;
                    clickParentNode(findById(sourceNodeInfo, addFriSuccessButtonId, 0));
                }
            }

//            //提示
//            //com.tencent.mm:id/djs
            AccessibilityNodeInfo djsNodeInfo = findById(sourceNodeInfo, dialogTitleId, 0);
            if (djsNodeInfo != null) {
                clickParentNode(findById(sourceNodeInfo, dialogButtonId, 0));
                sleep(AccessibilityUtils.DefaultMillis);
                back(automationAccessibilityService);
            }
//
//            //多按3点 取消
//            //com.tencent.mm:id/dk9
//            AccessibilityNodeInfo dk9NodeInfo = findById(sourceNodeInfo, "com.tencent.mm:id/dk9", 0);
//            String dk9Text = findTextByNodeInfo(dk9NodeInfo);
//            if (dk9Text != null && "取消".equals(dk9Text)) {
//                clickParentNode(dk9NodeInfo);
//            }
        }

    }

}
