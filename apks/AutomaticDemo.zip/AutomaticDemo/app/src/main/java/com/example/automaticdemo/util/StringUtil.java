package com.example.automaticdemo.util;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.net.URLEncoder;

public class StringUtil {

    public static String decodeUtf8(String s) {
        if (StringUtil.isNullOrEmpty(s))
            return "";
        try {
            return URLDecoder.decode(s, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String encodeUtf8(String s) {
        try {
            return URLEncoder.encode(s, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return "";
    }


    public static boolean isNullOrEmpty(String s) {
        if (s == null || "".equals(s))
            return true;
        return false;
    }

    public static double doubleDecimal(double d) {
        BigDecimal bigDecimal = new BigDecimal(d).setScale(2, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }

}
